# Synthetic Data Catalog

All records are synthetic. The data intentionally contains realistic variation, edge cases, limited missingness, inconsistent legacy classifications and selected integrity anomalies for discovery and transformation exercises.

## `assets.csv`
- Rows: 2,400
- Columns: `asset_id`, `plant`, `asset_type`, `status`, `install_year`, `oem`, `criticality`

## `baseline_metrics.csv`
- Rows: 180
- Columns: `date`, `work_items`, `avg_cycle_minutes`, `manual_effort_hours`, `error_rate_pct`, `exception_rate_pct`, `estimated_cost_units`

## `maintenance_history.csv`
- Rows: 1,200
- Columns: `maintenance_id`, `asset_id`, `work_type`, `failure_code`, `labor_hours`, `parts_cost`, `result`

## `production_orders.csv`
- Rows: 4,000
- Columns: `production_order_id`, `plant`, `sku`, `planned_qty`, `scrap_qty`, `status`, `source`

## `quality_events.csv`
- Rows: 8,000
- Columns: `quality_event_id`, `plant`, `production_order_id`, `defect_type`, `severity`, `status`, `confidence`, `source`

## `sensor_readings.csv`
- Rows: 14,000
- Columns: `reading_id`, `asset_id`, `metric`, `value`, `unit`, `timestamp`

## `suppliers.csv`
- Rows: 1,200
- Columns: `supplier_id`, `name`, `country`, `quality_rating`, `on_time_pct`, `status`

## `work_orders.csv`
- Rows: 6,500
- Columns: `work_order_id`, `asset_id`, `type`, `status`, `crew`, `downtime_minutes`, `priority`
