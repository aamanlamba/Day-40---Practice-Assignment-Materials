import pandas as pd
from pathlib import Path
DATA=Path(__file__).resolve().parents[1]/"data"
prod=pd.read_csv(DATA/"production_orders.csv")
# crude proxy retained from old reporting job
prod["yield_pct"]=(prod["planned_qty"]-prod["scrap_qty"])/prod["planned_qty"]*100
print(prod.groupby("plant").yield_pct.mean())
