def oee(availability, performance, quality):
    # Some callers pass 0-1, some pass 0-100.
    return availability * performance * quality

def critical_asset(asset):
    return asset.get("criticality") == "A" or asset.get("status") == "DOWN"
