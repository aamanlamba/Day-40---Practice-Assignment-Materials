# Synthetic Data Catalog

All records are synthetic. The data intentionally contains realistic variation, edge cases, limited missingness, inconsistent legacy classifications and selected integrity anomalies for discovery and transformation exercises.

## `adverse_events.csv`
- Rows: 4,200
- Columns: `ae_id`, `subject_id`, `event_term`, `severity`, `serious`, `causality`, `status`, `onset_date`

## `baseline_metrics.csv`
- Rows: 180
- Columns: `date`, `work_items`, `avg_cycle_minutes`, `manual_effort_hours`, `error_rate_pct`, `exception_rate_pct`, `estimated_cost_units`

## `batches.csv`
- Rows: 2,300
- Columns: `batch_id`, `product`, `status`, `site`, `assay_result`, `unit`

## `capa.csv`
- Rows: 1,800
- Columns: `capa_id`, `area`, `classification`, `status`, `root_cause_category`, `days_to_due`

## `documents.csv`
- Rows: 5,000
- Columns: `document_id`, `type`, `status`, `version`, `owner_group`, `classification`

## `lab_results.csv`
- Rows: 1,200
- Columns: `lab_result_id`, `subject_id`, `test_name`, `value`, `unit`, `flag`, `sample_date`

## `studies.csv`
- Rows: 1,200
- Columns: `study_id`, `phase`, `therapeutic_area`, `sponsor_region`, `status`, `planned_subjects`

## `subjects.csv`
- Rows: 3,000
- Columns: `subject_id`, `study_id`, `country`, `sex`, `age`, `status`, `consent_flag`
