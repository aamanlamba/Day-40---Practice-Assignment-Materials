def expedited_reporting(ae):
    # Oversimplified legacy decision rule.
    return ae.get("serious") == "Y" and ae.get("causality") != "UNRELATED"

def batch_release(row):
    return row.get("status") == "RELEASED" and 90 <= float(row.get("assay_result",0)) <= 110
