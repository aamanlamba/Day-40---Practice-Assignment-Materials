import pandas as pd
from pathlib import Path
DATA=Path(__file__).resolve().parents[1]/"data"
ae=pd.read_csv(DATA/"adverse_events.csv")
# Legacy operational shortcut: any severe event is escalated, regardless of seriousness/causality.
ae["needs_followup"]=(ae.severity=="SEVERE")
print(ae.needs_followup.value_counts())
