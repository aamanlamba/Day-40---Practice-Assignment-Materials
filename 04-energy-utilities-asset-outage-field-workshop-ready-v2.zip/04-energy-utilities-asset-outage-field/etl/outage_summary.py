import pandas as pd
from pathlib import Path
DATA=Path(__file__).resolve().parents[1]/"data"
outages=pd.read_csv(DATA/"outages.csv")
# Ignores open outages with duration not yet known in real operational logic.
print(outages.groupby("region").agg({"customers_affected":"sum","duration_minutes":"mean"}))
