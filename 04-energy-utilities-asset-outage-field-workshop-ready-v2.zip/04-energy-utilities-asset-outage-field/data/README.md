# Synthetic Data Catalog

All records are synthetic. The data intentionally contains realistic variation, edge cases, limited missingness, inconsistent legacy classifications and selected integrity anomalies for discovery and transformation exercises.

## `assets.csv`
- Rows: 3,000
- Columns: `asset_id`, `region`, `asset_type`, `status`, `criticality`, `commission_year`

## `baseline_metrics.csv`
- Rows: 180
- Columns: `date`, `work_items`, `avg_cycle_minutes`, `manual_effort_hours`, `error_rate_pct`, `exception_rate_pct`, `estimated_cost_units`

## `crews.csv`
- Rows: 1,200
- Columns: `crew_id`, `region`, `skill`, `shift`, `availability`, `contractor_flag`

## `field_orders.csv`
- Rows: 6,500
- Columns: `field_order_id`, `asset_id`, `job_type`, `status`, `crew`, `age_hours`, `priority`

## `hse_incidents.csv`
- Rows: 1,600
- Columns: `incident_id`, `region`, `type`, `severity`, `status`, `party`

## `meter_events.csv`
- Rows: 12,000
- Columns: `event_id`, `meter_id`, `region`, `value`, `unit`, `quality`, `timestamp`

## `outages.csv`
- Rows: 4,500
- Columns: `outage_id`, `region`, `asset_id`, `cause`, `customers_affected`, `duration_minutes`, `status`

## `weather_events.csv`
- Rows: 1,200
- Columns: `weather_event_id`, `region`, `event_type`, `severity`, `start_ts`, `duration_hours`
