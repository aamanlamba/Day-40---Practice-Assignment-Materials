def outage_priority(customers_affected, criticality):
    # String/int inconsistency is intentionally preserved.
    if int(customers_affected) > 10000 or str(criticality) == "1":
        return "EMERGENCY"
    return "NORMAL"

def suspicious_meter(value, quality):
    return quality in ("MISSING","SUSPECT") or float(value) < 0
